#! /bin/bash
#them CD moi
themCD(){
	#lay ma
	ma=$(timMa CD.dat)
	regex=^[^:]*$
	#nhap ten bai hat
	echo nhap Ten Bai Hat
	read tenBH
	while ! [[ $tenBH =~ $regex ]]
	do
		echo Ten Bai Hat khong duoc chua dau ¨:¨
		echo nhap Ten Bai Hat
		read tenBH
	done
	#nhap ten ca si
	echo nhap Ten Ca Si
	read tenCS
	while ! [[ $tenCS =~ $regex ]]
	do
		echo Ten Ca Si khong duoc chua dau ¨:¨
		echo nhap Ten Ca Si
		read tenCS
	done
	#nhap ten tac gia
	echo nhap Ten Tac Gia
	read tenTG
	while ! [[ $tenTG =~ $regex ]]
	do
		echo Ten Tac Gia khong duoc chua dau ¨:¨
		echo nhap Ten Tac Gia
		read tenTG
	done
	#nhap the loai nhac
	echo nhap The Loai Nhac
	read theLoai
	while ! [[ $theLoai =~ $regex ]]
	do
		echo The Loai Nhac khong duoc chua dau ¨:¨
		echo nhap The Loai Nhac
		read theLoai
	done
	#nhap gia tien
	#gia tien khong the de trong
	#gia tien phai la so
	regex='^[0-9]+$'
	while ! [[ $giaTien =~ $regex ]]
	do
		echo Gia Tien phai la so nguyen
		echo nhap Gia Tien
		read giaTien
	done
	#in vao file CD.dat
	echo $ma:$tenBH:$tenCS:$tenTG:$theLoai:$giaTien>>CD.dat
}
#tim ma tiep theo cua file $1
timMa(){
	cat $1|cut -f1 -d:|(while read output
	do
		a[$output]=1
	done

	i=1
	while ! [ -z ${a[$i]} ]
	do
		let i=$i+1
	done
	echo $i
	)
}
#chinh sua thong tin CD
themTTCT(){
	echo nhap Ma cua CD muon sua
	read MaCD
	tt=$(cat CD.dat|grep ^$MaCD:.*:.*:.*:.*:.*$)
	if [ -z $tt 2>/dev/null ]
	then
		echo CD khong ton tai
		return
	fi

	TenBH=$(echo $tt|cut -f2 -d:)
	TenCS=$(echo $tt|cut -f3 -d:)
	TenTG=$(echo $tt|cut -f4 -d:)
	TheLoai=$(echo $tt|cut -f5 -d:)
	GiaTien=$(echo $tt|cut -f6 -d:)

	echo chon chi tiet muon sua
	echo 1: Ten Bai Hat
	echo 2: Ten Ca Si
	echo 3: Ten Tac Gia
	echo 4: The Loai
	echo 5: Gia Tien
	echo 6: Xem Thong Tin Chi Tiet
	echo 0: Luu Va Thoat Chinh Sua
	read n

	regex=^[^:]*$
	while [ $n != 0 ]
	do
		case $n in
			1)echo nhap Ten Bai Hat
				read TenBH
				while ! [[ $TenBH =~ $regex ]]
				do
					echo Ten Bai Hat khong duoc chua dau ¨:¨
					echo nhap Ten Bai Hat
					read TenBH
				done
				echo Ten Bai Hat: $TenBH;;
			2)echo nhap Ten Ca Si
				read TenCS
				while ! [[ $TenCS =~ $regex ]]
				do
					echo Ten Ca Si khong duoc chua dau ¨:¨
					echo nhap Ten Ca Si
					read TenCS
				done
				echo Ten Ca Si: $TenCS;;
			3)echo nhap Ten Tac Gia
				read TenTG
				while ! [[ $TenTG =~ $regex ]]
				do
					echo Ten Tac Gia khong duoc chua dau ¨:¨
					echo nhap Ten Tac Gia
					read TenTG
				done
				echo Ten Tac Gia: $TenTG;;
			4)echo nhap The Loai
				read TheLoai
				while ! [[ $TheLoai =~ $regex ]]
				do
					echo The Loai Nhac khong duoc chua dau ¨:¨
					echo nhap The Loai Nhac
					read TheLoai
				done
				echo The Loai: $TheLoai;;
			5)echo nhap Gia Tien
				regex1='^[0-9]+$'
				while ! [[ $gt =~ $regex1 ]]
				do
					echo so luong phai la chu so
					echo nhap Gia Tien
					read gt
				done
				GiaTien=$gt
				echo Gia Tien: $GiaTien;;
			6)echo $MaCD:$TenBH:$TenCS:$TenTG:$TheLoai:$GiaTien;;
			*)echo lua chon khong hop le;;
		esac

		echo chon chi tiet muon sua
		echo 1: Ten Bai Hat
		echo 2: Ten Ca Si
		echo 3: Ten Tac Gia
		echo 4: The Loai
		echo 5: Gia Tien
		echo 6:	Xem Thong Tin Chi Tiet
		echo 0: Luu Va Thoat Chinh Sua
		read n
	done

	cat CD.dat>CD.tmp
	printf >CD.dat 2>/dev/null

	cat CD.tmp|while read output
	do
		if [ $(echo $output|cut -f1 -d:) == $MaCD ]
		then
			echo $MaCD:$TenBH:$TenCS:$TenTG:$TheLoai:$GiaTien>>CD.dat
		else
			echo $output>>CD.dat
		fi
	done

	rm -f CD.tmp
}
#hien thi CD
hienthiCD(){
	pt=$1
	echo Nhap ma CD muon hien thi di ban
	read maCD
	hienCD $maCD $pt
}
hienCD(){
	tt=$(cat CD.dat|grep ^$1:.*:.*:.*:.*:.*$)
	if [ -z $tt 2>/dev/null ]
	then
		echo Co dia CD nay dau ma doi hien thi!!
	else
		#echo Ten ca si: $(echo $tt|cut -f2 -d:)
		tenCD=$(echo $tt|cut -f2 -d:)
		tenCS=$(echo $tt|cut -f3 -d:)
		tenNS=$(echo $tt|cut -f4 -d:)
		tl=$(echo $tt|cut -f5 -d:)
		gia=$(echo $tt|cut -f6 -d:)				
		if [ $2 == 1 ]
		then
			echo "------------------------"
			echo Ten CD: $tenCD
			echo Gia Ban: $gia
			echo "------------------------"
		fi
		if [ $2 == 2 ]
		then
			echo "------------------------"
			echo Ten CD: $tenCD
			echo Ten ca si: $tenCS
			echo Ten nhac si: $tenNS
			echo The loai: $tl
			echo Gia ban: $gia
			echo "------------------------"
		fi
	fi
}
#tim kiem CD theo the loai
timkiemTL()
{
	kq=0
	echo Nhap ten the loai can tim kiem:
	read tl
	while read -r line; do
		t=$(echo $line|cut -f5 -d:|grep -i "$tl")
		if ! [ -z $t 2>/dev/null ];then
			maCD=$(echo $line|cut -f1 -d:)
			kq=1
			hienCD $maCD 1
		fi
	done < CD.dat
	if [ $kq -eq 0 ];then
		echo "E kie^m' kho^ng ra a oi T_T"
	fi	
	#kq=$(cat CD.dat|grep ^.*:.*:.*:.*:$n:.*$)
	#if [ -z $kq 2>/dev/null ]
	#then
	#	echo "Co' cai' the^? loai. da^y da^u ma kie^m'!!"
	#else
	#	echo "Tim kiem xong roi. Nhap phuong thuc muon hien thi"
	#	maCD=$(echo $kq|cut -f1 -d:)
	#	hienCD $maCD
	#fi	
}
#timkiemTG
timkiemTG()
{
	kq=0
	echo "Nha^p. te^n ta'c gia? de^ ban. oi"
	read tG
	while read -r line; do
		t=$(echo $line|cut -f4 -d:|grep -i "$tG")
		if ! [ -z $t 2>/dev/null ];then
			maCD=$(echo $line|cut -f1 -d:)
			kq=1;
			hienCD $maCD 1
		fi
	done < CD.dat
	if [ $kq -eq 0 ];then
		echo "E kie^m' kho^ng ra a oi T_T"
	fi
		
}
#tim kiem theo ten bai hat
timkiemBH()
{
	kq=0
	echo "Nha^p te^n bai ha't de^ ba.n oi"
	read bh
	while read -r line; do
		t=$(echo $line|cut -f2 -d:|grep -i "$bh")
		if ! [ -z $t 2>/dev/null ];then
			echo $t
			maCD=$(echo $line|cut -f1 -d:)
			kq=1;
			hienCD $maCD 1
		fi
	done < CD.dat
	if [ $kq -eq 0 ];then
		echo "E kie^m' kho^ng ra a oi T_T"
	fi
}
# them HD
themHD(){
	#max la do dai mang a[]
	max=-1
	echo 1: them CTHD
	echo 0: ket thuc them HD
	read n
	while [ $n != 0 ]
	do
		if [ $n == 1 ]
		then
			echo nhap MaCD muon ban
			read MaCD
			#kiem tra MaCD co ton tai
			tt=$(cat CD.dat|grep ^$MaCD:.*:.*:.*:.*:.*$)
			if [ -z $tt 2>/dev/null ]
			then
				echo CD khong ton tai
			else
				#kiem tra so luong ban
				echo nhap so luong ban
				read soluong
				regex1='^[0-9]+$'
				if ! [[ $soluong =~ $regex1 ]]
				then
					echo so luong phai la chu so
				elif [ $soluong -lt 1 ]
				then
					echo so luong mua qua it, khong ban
				else
					#ghi so luong ban vao mang theo MaCD
					#(giong voi Counting Sort)
					a[$MaCD]=$soluong
					if [ $MaCD -gt $max ]
					then
						max=$MaCD
					fi
				fi
			fi
		else echo lua chon ko hop le
		fi
		echo 1: them CTHD
		echo 0: ket thuc them HD
		read n
	done
	#ghi mang vao file CTHD.dat
	MaHD=$(timMa CTHD.dat)
	i=1
	while [ $i -le $max ]
	do
		if ! [ -z ${a[$i]} ]
		then
			echo $MaHD:$i:${a[$i]} >> CTHD.dat
		fi
		let i=$i+1
	done
}
inHD(){
	echo 1: xem hoa don
	echo 2: xem tat ca hoa don
	echo 0: ket thuc xem hoa don
	cat CD.dat|cut -f1,6 -d:>CD.tmp
	while read output1;
	do
		a[$(echo $output1|cut -f1 -d:)]=$(echo $output1|cut -f2 -d:)
	done<CD.tmp
	rm -f CD.tmp
	read n
	while ! [ $n == 0 ]
	do
		if [ $n == 1 ]
		then
			echo nhap Ma Hoa Don
			read MaHD
			if [ -z $(cat CTHD.dat|grep ^$MaHD:.*:.*$) 2>/dev/null ]
			then
				echo Hoa Don khong ton tai
			else
				tong=0
				cat CTHD.dat|grep ^$MaHD:.*:.*$|(while read output
				do
					let tong=$tong+$(echo $output|cut -f3 -d:)*${a[$(echo $output|cut -f2 -d:)]}
				done
				echo tong cong: $tong dong)
			fi
		elif [ $n == 2 ]
		then
			max=0
			unset b
			cat CTHD.dat|(while read output
			do
				t=$(echo $output|cut -f1 -d:)
				if [ -z ${b[$t]} ]
				then
					b[$t]=0
				fi
				let b[$t]=b[$t]+${a[$(echo $output|cut -f2 -d:)]}*$(echo $output|cut -f3 -d:)
				if [ ${b[$t]} -gt $max ]
				then
					max=$t
				fi
			done
			i=1
			while [ $i -le $max ]
			do
				if ! [ -z ${b[$i]} ]
				then
					echo hoa don $i tri gia ${b[$i]}
				fi
				let i=$i+1
			done
			)
		else
			echo nhap khong hop le
		fi
	echo 1: xem hoa don
	echo 2: xem tat ca hoa don
	echo 0: ket thuc xem hoa don
	read n
	done
}
main(){
	echo 1: Them CD
	echo 2: Them Thong Tin Chi Tiet CD
	echo 3: Hien thi thong tin ngan gon cua CD
	echo 4: Hien thi thong tin chi tiet cua CD
	echo 5: Tim Kiem CD Theo The Loai
	echo 6: Tim Kiem CD Theo Tac Gia
	echo 7: Tim Kiem CD Theo Ten Bai Hat
	echo 8: Ban CD '(Tao Hoa Don)'
	echo 9: In Hoa Don Ban Hang
	echo 0: Thoat Chuong Trinh
	read n

	while [ $n != 0 ]
	do
	case $n in
		1)themCD;;
		2)themTTCT;;
		3)hienthiCD 1;;
		4)hienthiCD 2;;
		5)timkiemTL;;
		6)timkiemTG;;
		7)timkiemBH;;
		8)themHD;;
		9)inHD;;
		*)echo nhap khong hop le;;
	esac
		echo 1: Them CD
		echo 2: Them Thong Tin Chi Tiet CD
		echo 3: Hien Thi Thong Tin ngan gon cua CD
		echo 4: Hien thi thong tin chi tiet cua CD
		echo 5: Tim Kiem CD Theo The Loai
		echo 6: Tim Kiem CD Theo Tac Gia
		echo 7: Tim Kiem CD Theo Ten Bai Hat
		echo 8: Ban CD '(Tao Hoa Don)'
		echo 9: In Hoa Don Ban Hang
		echo 0: Thoat Chuong Trinh
		read n
	done
}
main
